function addition()
{
	var num1=prompt("enter first number");
	var a=parseInt(num1);
	var num2=prompt("enter second number");
	var b=parseInt(num2);
	var num3=a+b;
	alert("addition is"+num3);
}